test = {   'name': 'posteriors',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': ">>> (0 <= posterior_madison <= 1) and (0 <= posterior_hamilton <= 1) and (sample_classification == 'Hamilton' or sample_classification == 'Madison')\n"
                                               'True',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
