test = {   'name': 'log_posteriors',
    'points': 1,
    'suites': [   {   'cases': [{'code': '>>> (log_posterior_madison < 0 ) and (log_posterior_hamilton < 0)\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
