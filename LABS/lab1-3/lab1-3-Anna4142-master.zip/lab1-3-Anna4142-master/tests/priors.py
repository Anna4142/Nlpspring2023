test = {   'name': 'priors',
    'points': 1,
    'suites': [   {   'cases': [{'code': '>>> (0 <= prior_madison <= 1) and (0 <= prior_hamilton <= 1)\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
