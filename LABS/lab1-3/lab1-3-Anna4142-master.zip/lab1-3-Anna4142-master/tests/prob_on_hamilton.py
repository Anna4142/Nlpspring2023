test = {   'name': 'prob_on_hamilton',
    'points': 1,
    'suites': [{'cases': [{'code': '>>> 0 <= prob_on_hamilton <= 1\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
