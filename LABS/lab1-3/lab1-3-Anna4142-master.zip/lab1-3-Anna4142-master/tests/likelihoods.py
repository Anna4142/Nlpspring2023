test = {   'name': 'likelihoods',
    'points': 1,
    'suites': [   {   'cases': [{'code': '>>> (0 <= likelihood_hamilton <= 1) and (0 <= likelihood_madison <= 1)\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
