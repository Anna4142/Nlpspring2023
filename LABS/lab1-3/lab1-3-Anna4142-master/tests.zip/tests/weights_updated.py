test = {   'name': 'weights_updated',
    'points': 1,
    'suites': [{'cases': [{'code': '>>> weights_updated.size()\ntorch.Size([4])', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
