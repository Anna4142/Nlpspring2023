test = {   'name': 'prob_hamilton_examples',
    'points': 1,
    'suites': [   {   'cases': [{'code': '>>> (0 < prob_hamilton_example0 < 1) and (0 < prob_hamilton_example9 < 1)\ntensor(True)', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
