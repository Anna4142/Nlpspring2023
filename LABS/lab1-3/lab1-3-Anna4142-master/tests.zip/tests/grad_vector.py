test = {   'name': 'grad_vector',
    'points': 1,
    'suites': [{'cases': [{'code': '>>> grad_vector.size()\ntorch.Size([4])', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
