test = {   'name': 'loss_example0_old_and_new',
    'points': 1,
    'suites': [   {   'cases': [{'code': '>>> (loss_example0_new > 0) and (loss_example0_old > 0)\ntensor(True)', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
