test = {   'name': 'sigma',
    'points': 1,
    'suites': [   {   'cases': [{'code': '>>> torch.isclose(sigma(torch.tensor(0)), torch.tensor(0.5))\ntensor(True)', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
