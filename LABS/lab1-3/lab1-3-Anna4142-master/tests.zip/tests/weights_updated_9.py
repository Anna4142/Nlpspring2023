test = {   'name': 'weights_updated_9',
    'points': 1,
    'suites': [   {   'cases': [{'code': '>>> loss_example9_old != ... \\\n... and loss_example9_new != ... \\\n... and loss_example9_updated != ...\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
