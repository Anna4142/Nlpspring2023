test = {   'name': 'prob_hamilton_examples_new',
    'points': 1,
    'suites': [   {   'cases': [{'code': '>>> (0 < prob_hamilton_example0_new < 1) and (0 < prob_hamilton_example9_new < 1)\ntensor(True)', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
