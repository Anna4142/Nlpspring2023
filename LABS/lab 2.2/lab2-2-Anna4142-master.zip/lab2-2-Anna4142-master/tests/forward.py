test = {   'name': 'forward',
    'points': 1,
    'suites': [   {   'cases': [{'code': '>>> o1.detach().shape, o2.detach().shape\n(torch.Size([2]), torch.Size([2]))', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
