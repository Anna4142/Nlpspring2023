test = {   'name': 'bigram',
    'points': 1,
    'suites': [   {   'cases': [{'code': '>>> ((0 <= float(sequence_probability(seq1, T)) <= 1) \n...  and (0 <= float(sequence_probability(seq2, T)) <= 1))\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
