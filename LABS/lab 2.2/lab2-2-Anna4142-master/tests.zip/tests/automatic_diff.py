test = {   'name': 'automatic_diff',
    'points': 1,
    'suites': [{'cases': [{'code': '>>> U_grad.shape\ntorch.Size([2, 2])', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
