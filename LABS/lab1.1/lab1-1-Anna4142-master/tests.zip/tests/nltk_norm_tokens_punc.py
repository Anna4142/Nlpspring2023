test = {   'name': 'nltk_norm_tokens_punc',
    'points': 1,
    'suites': [{'cases': [{'code': '>>> nltk_norm_tokens_punc != ...\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
