test = {   'name': 'hamming_distance',
    'points': 1,
    'suites': [   {   'cases': [{'code': '>>> hamming_distance(torch.tensor([0, 0, 1]), torch.tensor([0, 1, 1])) == 1\ntensor(True)', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
