test = {   'name': 'anywhere_1hot',
    'points': 1,
    'suites': [{'cases': [{'code': '>>> type(anywhere_1hot) == torch.Tensor\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
