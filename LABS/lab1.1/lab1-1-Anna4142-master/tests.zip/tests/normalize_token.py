test = {   'name': 'normalize_token',
    'points': 1,
    'suites': [{'cases': [{'code': '>>> normalize_token("Sam") == "sam"\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
