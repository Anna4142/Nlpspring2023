test = {   'name': 'example_bow',
    'points': 1,
    'suites': [{'cases': [{'code': '>>> example_bow.max() > 1\ntensor(True)', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
