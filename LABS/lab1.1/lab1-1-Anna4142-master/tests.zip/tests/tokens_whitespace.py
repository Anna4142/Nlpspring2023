test = {   'name': 'tokens_whitespace',
    'points': 1,
    'suites': [{'cases': [{'code': '>>> tokens != ...\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
