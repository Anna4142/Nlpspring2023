test = {   'name': 'anywhere_1hot_reverse',
    'points': 1,
    'suites': [   {   'cases': [{'code': ">>> onehot_to_str(anywhere_1hot, vocabulary) == 'anywhere'\nTrue", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
