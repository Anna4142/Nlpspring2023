test = {   'name': 'euclidean_distance',
    'points': 1,
    'suites': [   {   'cases': [{'code': '>>> euclidean_distance(torch.tensor([0., 0., 1.]), torch.tensor([0., 1., 1.]))\ntensor(1.)', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
