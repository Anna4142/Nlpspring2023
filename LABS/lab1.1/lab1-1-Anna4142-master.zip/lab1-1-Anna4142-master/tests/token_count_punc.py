test = {   'name': 'token_count_punc',
    'points': 1,
    'suites': [{'cases': [{'code': '>>> token_count_3 > 0\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
