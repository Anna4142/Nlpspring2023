test = {   'name': 'example_sow',
    'points': 1,
    'suites': [{'cases': [{'code': '>>> type(example_sow) == torch.Tensor\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
