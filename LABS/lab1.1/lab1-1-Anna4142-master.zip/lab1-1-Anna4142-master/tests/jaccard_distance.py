test = {   'name': 'jaccard_distance',
    'points': 1,
    'suites': [   {   'cases': [{'code': '>>> jaccard_distance(torch.tensor([0., 0., 1.]), torch.tensor([0., 1., 1.])) - 5 < 1e-5\ntensor(True)', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
