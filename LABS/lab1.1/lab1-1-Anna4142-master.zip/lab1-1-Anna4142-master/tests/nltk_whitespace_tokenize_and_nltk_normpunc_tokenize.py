test = {   'name': 'nltk_whitespace_tokenize_and_nltk_normpunc_tokenize',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': '>>> nltk_whitespace_tokenize("Would you like them here or there?") \\\n'
                                               "...   == ['Would', 'you', 'like', 'them', 'here', 'or', 'there?']\n"
                                               'True',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
