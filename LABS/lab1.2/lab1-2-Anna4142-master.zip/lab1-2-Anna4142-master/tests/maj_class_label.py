test = {   'name': 'maj_class_label',
    'points': 1,
    'suites': [{'cases': [{'code': '>>> type(maj_class_label) == str\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
