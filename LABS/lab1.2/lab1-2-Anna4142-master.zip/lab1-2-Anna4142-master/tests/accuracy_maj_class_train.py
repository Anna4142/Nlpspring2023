test = {   'name': 'accuracy_maj_class_train',
    'points': 1,
    'suites': [{'cases': [{'code': '>>> 0 <= accuracy_maj_class_train <= 1\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
