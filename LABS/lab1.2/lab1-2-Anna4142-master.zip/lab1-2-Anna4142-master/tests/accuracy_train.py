test = {   'name': 'accuracy_train',
    'points': 1,
    'suites': [   {   'cases': [{'code': '>>> (0 <= accuracy_nn_euclidean_train <= 1) and (0 <= accuracy_nn_cosine_train <= 1)\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
