test = {   'name': 'cosine_distance',
    'points': 1,
    'suites': [   {   'cases': [{'code': '>>> round(cosine_distance(torch.tensor([0., 0., 1.]), torch.tensor([0., 1., 1.])), 5)\n0.25', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
