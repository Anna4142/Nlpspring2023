test = {   'name': 'get_gold',
    'points': 1,
    'suites': [   {   'cases': [   {'code': ">>> testing_gold[0]['authors'] == 'Madison'\nTrue", 'hidden': False, 'locked': False},
                                   {'code': ">>> testing[0]['authors']\n'Hamilton or Madison'", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
