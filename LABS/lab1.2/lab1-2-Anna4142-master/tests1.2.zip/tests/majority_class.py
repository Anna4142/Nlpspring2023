test = {   'name': 'majority_class',
    'points': 1,
    'suites': [{'cases': [{'code': '>>> type(majority_class(None)) == str\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
