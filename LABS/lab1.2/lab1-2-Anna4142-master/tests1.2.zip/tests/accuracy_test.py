test = {   'name': 'accuracy_test',
    'points': 1,
    'suites': [   {   'cases': [{'code': '>>> (0 <= accuracy_nn_cosine_test <= 1) and (0 <= accuracy_nn_euclidean_test <= 1)\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
