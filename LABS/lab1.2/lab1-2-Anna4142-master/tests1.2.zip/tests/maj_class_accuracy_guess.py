test = {   'name': 'maj_class_accuracy_guess',
    'points': 1,
    'suites': [{'cases': [{'code': '>>> 0 <= maj_class_accuracy_guess <= 1\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
