test = {   'name': 'majority_class_label',
    'points': 1,
    'suites': [{'cases': [{'code': '>>> type(majority_class_label(training)) == str\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
