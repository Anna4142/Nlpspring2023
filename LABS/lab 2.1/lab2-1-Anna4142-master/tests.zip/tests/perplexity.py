test = {   'name': 'perplexity',
    'points': 1,
    'suites': [{'cases': [{'code': '>>> perplexity(test_tokens, unigram_model, 1) > 1\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
