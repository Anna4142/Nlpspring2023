test = {   'name': 'ngram_counts',
    'points': 1,
    'suites': [   {   'cases': [{'code': '>>> sum(len(unigram_counts[cntxt]) for cntxt in unigram_counts)\n59', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
