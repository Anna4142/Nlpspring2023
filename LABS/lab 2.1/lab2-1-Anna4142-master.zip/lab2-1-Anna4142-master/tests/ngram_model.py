test = {   'name': 'ngram_model',
    'points': 1,
    'suites': [   {   'cases': [{'code': '>>> round(math.log2(ngram_model(unigram_counts)[()]["sam"]), 3)\n-7.839', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
