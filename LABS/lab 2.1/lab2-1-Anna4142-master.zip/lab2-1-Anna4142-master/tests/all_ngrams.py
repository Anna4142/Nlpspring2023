test = {   'name': 'all_ngrams',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': '>>> print(sorted(all_ngrams(["one", "two"], 3)))\n'
                                               "[('one', 'one', 'one'), ('one', 'one', 'two'), ('one', 'two', 'one'), ('one', 'two', 'two'), ('two', 'one', 'one'), ('two', 'one', 'two'), ('two', "
                                               "'two', 'one'), ('two', 'two', 'two')]\n",
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
