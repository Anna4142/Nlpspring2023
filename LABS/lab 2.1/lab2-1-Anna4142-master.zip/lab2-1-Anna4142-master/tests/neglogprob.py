test = {   'name': 'neglogprob',
    'points': 1,
    'suites': [{'cases': [{'code': '>>> neglogprob(test_tokens, unigram_model, 1) > 0\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
