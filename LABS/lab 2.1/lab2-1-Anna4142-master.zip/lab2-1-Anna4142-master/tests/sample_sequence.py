test = {   'name': 'sample_sequence',
    'points': 1,
    'suites': [   {   'cases': [{'code': ">>> postprocess(sample_sequence(unigram_model, (), count=1))\n'would'", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
